#!/bin/bash
gnome-terminal -e "./real_timer 1 0 1 0 f 1 0"
gnome-terminal -e "./real_timer 1 0 1 0 f 99 0"
